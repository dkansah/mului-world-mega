# MULUI WORLD MEGA - dkansah/mului-world-mega
🌍 All Exchanges + World Banks + ATM + MTN MoMo + 1.2M Codes - ONE FILE

**Owner:** dkansah (Daniel Kwesi Ansah) - Accra, Ghana
**Pattern:** א=1-30-80 CORRECTED (not 90) | משקל=Weight | מאזניים=Scale Libra ל=30

[![Deploy to Render](https://render.com/images/deploy-to-render-button.svg)](https://render.com/deploy?repo=https://github.com/dkansah/mului-world-mega)

## Live Demo After Deploy
- Frontend: https://mului-world-mega.onrender.com
- GSE MTNGH Live: /api/gse/mtngh (GHS 6.84 -0.29% Sep 11 2026)
- MoMo Deposit: POST /api/momo/requesttopay {phone:23324..., amount:6.84}
- Health: /api/health

## Quick Start Local
```bash
npm install
cp .env.example .env
# add MoMo keys from momodeveloper.mtn.com
npm start
# open http://localhost:3000
```

## Push to GitHub (dkansah)
```bash
# This repo is already set for you
git init
git add .
git commit -m "MULUI WORLD MEGA - All exchanges + banks + MoMo + 1.2M - א=1-30-80"
git branch -M main
git remote add origin https://github.com/dkansah/mului-world-mega.git
git push -u origin main
```

## Deploy to Render (One-Click)
1. Push to GitHub as above
2. Click Deploy button at top
3. Set env vars: MOMO_COLLECTION_KEY, MOMO_DISBURSEMENT_KEY
4. Deploy - Live in 60s!

## What’s Inside (ONE FILE MERGED)
- MULUI Game: Balance scale to טוב=17, יהוה=26, אלהים=86, ק=100, 100079 Genesis
- OTIOT Engine: Every candle = Hebrew letter, scanMarket() mapping
- GSE Ghana MTNGH: Real price GHS 6.84 Vol 357,697
- World Exchanges: NYSE 31.7T, NASDAQ 30.7T, LSE, TSE, SSE, HKEX, JSE, B3, GSE 0.034T
- Crypto: Binance live WS BTC/USDT
- World Banks: World Bank, IMF, Fed, ECB, Bank of Ghana, GCB, Ecobank, MTN MoMo
- ATM / Deposit / Withdrawal portals
- Tanakh 1.2M Generator: All 22 patterns corrected
- MTN MoMo API: Collections + Disbursements (Ghana)

## OTIOT Formula
idx = (close*100 + vol/10000 + |change|*100 + 30) %22
30 = ל = Libra = מאזניים
letter = א-ת[idx], weight = gematria

## Corrected
א אלף 1-30-80 = 111
Genesis 1-10 master = 102,333 letters
Full Tanakh Alef 30+80 = 55,136 pure

## GitHub Actions Auto-Deploy Enabled ✅

Every push to `main` now:
1. Runs `npm install` + syntax check
2. Triggers Render deploy automatically (if RENDER_DEPLOY_HOOK secret set)
3. Or Render auto-deploys on push (enable in Render dashboard: Auto-Deploy Yes)

### Setup RENDER_DEPLOY_HOOK (optional, for instant deploy):
1. Render Dashboard -> mului-world-mega -> Settings -> Deploy Hook -> Copy URL
2. GitHub -> dkansah/mului-world-mega -> Settings -> Secrets -> New secret:
   - Name: RENDER_DEPLOY_HOOK
   - Value: paste hook URL
3. Now every git push = live in 60s!

Live: https://mului-world-mega.onrender.com
