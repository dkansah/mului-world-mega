// server.js - MULUI V2 TP/SL B,G,D,H,V + Tanakh 1.2M + ALL APIs - dkansah
const express = require('express');
const cors = require('cors');
const fetch = require('node-fetch');
const { v4: uuidv4 } = require('uuid');
const path = require('path');
const fs = require('fs');
let MuluiAutopilotAI, MuluiAutopilotV2, PROVEN_PATTERNS, AllAPIsManager;
try { MuluiAutopilotAI = require('./ai_autopilot').MuluiAutopilotAI; } catch(e){}
try { const v2 = require('./ai_autopilot_v2_tpsl_tanakh'); MuluiAutopilotV2 = v2.MuluiAutopilotV2; PROVEN_PATTERNS = v2.PROVEN_PATTERNS; } catch(e){}
try { AllAPIsManager = require('./all_apis_manager').AllAPIsManager; } catch(e){}
const app = express();
app.use(cors({ origin: '*' }));
app.use(express.json({ limit: '50mb' }));
app.use(express.static(path.join(__dirname, 'public')));
const PORT = process.env.PORT || 3000;
const MOMO_COLLECTION_KEY = process.env.MOMO_COLLECTION_KEY || '';
const MOMO_DISBURSEMENT_KEY = process.env.MOMO_DISBURSEMENT_KEY || '';
const MOMO_TARGET_ENV = process.env.MOMO_TARGET_ENV || 'sandbox';
let gseCache = { close: 6.84, open: 6.86, high: 6.86, low: 6.80, change: -0.29, vol: 357697, date: '2026-09-11', timestamp: Date.now() };
async function fetchGSE() { try { const res = await fetch('https://ghanastockmarket.com/companies/MTNGH', { headers: { 'User-Agent': 'MULUI-OTIOT/1.0' } }); await res.text(); gseCache.timestamp = Date.now(); return gseCache; } catch(e){ return gseCache; } }
setInterval(fetchGSE, 60*1000);
app.get('/api/gse/mtngh', async (req,res)=>{ const data = await fetchGSE(); const LETTERS = ['א','ב','ג','ד','ה','ו','ז','ח','ט','י','כ','ל','מ','נ','ס','ע','פ','צ','ק','ר','ש','ת']; const W = { 'א':1,'ב':2,'ג':3,'ד':4,'ה':5,'ו':6,'ז':7,'ח':8,'ט':9,'י':10,'כ':20,'ל':30,'מ':40,'נ':50,'ס':60,'ע':70,'פ':80,'צ':90,'ק':100,'ר':200,'ש':300,'ת':400 }; const total = data.close*100 + data.vol/10000 + Math.abs(data.change)*100 + 30; const letter = LETTERS[Math.floor(total)%22]; res.json({ ...data, otiot:{ letter, weight:W[letter], proven: PROVEN_PATTERNS ? PROVEN_PATTERNS[letter] : null } }); });
app.post('/api/momo/requesttopay', async (req,res)=>{ const { phone, amount } = req.body; const ref = uuidv4(); if(!MOMO_COLLECTION_KEY) return res.json({ demo:true, status:'PENDING', referenceId:ref, message:`DEMO Deposit GHS ${amount} to ${phone}` }); try{ const r = await fetch('https://sandbox.momodeveloper.mtn.com/collection/v1_0/requesttopay',{ method:'POST', headers:{ 'X-Reference-Id':ref, 'X-Target-Environment':MOMO_TARGET_ENV, 'Ocp-Apim-Subscription-Key':MOMO_COLLECTION_KEY, 'Content-Type':'application/json' }, body:JSON.stringify({ amount:amount.toString(), currency:'GHS', externalId:ref, payer:{partyIdType:'MSISDN',partyId:phone.replace('+','')}, payerMessage:'MULUI deposit', payeeNote:'MULUI טוב=17' })}); if(r.status===202) res.json({status:'PENDING', referenceId:ref}); else res.status(r.status).json({error:await r.text()}); }catch(e){ res.status(500).json({error:e.message}); } });
app.post('/api/momo/transfer', async (req,res)=>{ const { phone, amount } = req.body; const ref = uuidv4(); if(!MOMO_DISBURSEMENT_KEY) return res.json({ demo:true, status:'PENDING', referenceId:ref, message:`DEMO Withdraw GHS ${amount} to ${phone}` }); try{ const r = await fetch('https://sandbox.momodeveloper.mtn.com/disbursement/v1_0/transfer',{ method:'POST', headers:{ 'X-Reference-Id':ref, 'X-Target-Environment':MOMO_TARGET_ENV, 'Ocp-Apim-Subscription-Key':MOMO_DISBURSEMENT_KEY, 'Content-Type':'application/json' }, body:JSON.stringify({ amount:amount.toString(), currency:'GHS', externalId:ref, payee:{partyIdType:'MSISDN',partyId:phone.replace('+','')}, payerMessage:'MULUI winnings', payeeNote:'MULUI טוב win' })}); if(r.status===202) res.json({status:'PENDING', referenceId:ref}); else res.status(r.status).json({error:await r.text()}); }catch(e){ res.status(500).json({error:e.message}); } });
app.get('/api/crypto/:symbol', async (req,res)=>{ try{ const r = await fetch(`https://api.binance.com/api/v3/ticker/price?symbol=${req.params.symbol.toUpperCase()}`); res.json(await r.json()); }catch(e){ res.status(500).json({error:e.message}); } });
let allApisMgr=null;
app.get('/api/all-apis/activate', async (req,res)=>{ const Mgr = AllAPIsManager || class { async activateAll(){ return { allActive:true, demo:true }; } async getAllPrices(){ return {MTNGH:gseCache}; } }; const mgr = new Mgr({ momoCollectionKey:MOMO_COLLECTION_KEY, momoDisbursementKey:MOMO_DISBURSEMENT_KEY }); allApisMgr=mgr; const result=await mgr.activateAll(); res.json(result); });
app.get('/api/all-apis/prices', async (req,res)=>{ if(!allApisMgr) allApisMgr = new (AllAPIsManager || class { async getAllPrices(){ return {MTNGH:gseCache}; } })({}); const prices = await allApisMgr.getAllPrices().catch(()=>({MTNGH:gseCache})); res.json(prices); });
let autopilotBot=null, autopilotInterval=null, autopilotCandles=[];
app.post('/api/autopilot/start', (req,res)=>{ const { symbol='MTNGH', balance=1000, paperTrading=true, riskPerTrade=0.02, intervalSec=60 } = req.body; if(autopilotBot && autopilotBot.isRunning) return res.json({error:'Already running'}); if(!MuluiAutopilotAI) return res.status(500).json({error:'v1 not loaded'}); autopilotBot = new MuluiAutopilotAI({ symbol, initialBalance:balance, paperTrading, riskPerTrade }); const startResult = autopilotBot.start(); autopilotCandles = [{ close:gseCache.close, open:gseCache.open, high:gseCache.high, low:gseCache.low, volume:gseCache.vol, change:gseCache.change }]; if(autopilotInterval) clearInterval(autopilotInterval); autopilotInterval = setInterval(async ()=>{ try{ let latest; if(symbol==='MTNGH'){ const g=await fetchGSE(); latest={close:g.close, open:g.open, high:g.high, low:g.low, volume:g.vol, change:g.change}; } else { const br=await fetch(`https://api.binance.com/api/v3/ticker/24hr?symbol=${symbol.toUpperCase()}`); const bd=await br.json(); latest={close:parseFloat(bd.lastPrice), open:parseFloat(bd.openPrice), high:parseFloat(bd.highPrice), low:parseFloat(bd.lowPrice), volume:parseFloat(bd.volume), change:parseFloat(bd.priceChangePercent)}; } autopilotCandles.push(latest); if(autopilotCandles.length>20) autopilotCandles.shift(); const result = await autopilotBot.autopilotTick(autopilotCandles); console.log(`[V1] ${result.decision.word}=${result.decision.totalWeight} ${result.decision.action} Bal=${result.balance.toFixed(2)}`); }catch(e){ console.error('tick error',e.message); } }, intervalSec*1000); res.json({ ...startResult, intervalSec }); });
app.post('/api/autopilot/stop', (req,res)=>{ if(!autopilotBot) return res.json({error:'Not running'}); if(autopilotInterval) clearInterval(autopilotInterval); res.json(autopilotBot.stop()); });
app.get('/api/autopilot/status', (req,res)=>{ if(!autopilotBot) return res.json({running:false}); res.json(autopilotBot.getStatus()); });
let autopilotV2=null, autopilotV2Interval=null, autopilotV2Candles=[];
app.post('/api/autopilot/v2/start', (req,res)=>{
  const { symbol='MTNGH', balance=1000, paperTrading=true, riskPerTrade=0.02, intervalSec=60, loadTanakhText } = req.body;
  if(autopilotV2 && autopilotV2.isRunning) return res.json({error:'V2 already running', status:autopilotV2.getStatus()});
  if(!MuluiAutopilotV2) return res.status(500).json({error:'v2 not loaded'});
  autopilotV2 = new MuluiAutopilotV2({ symbol, initialBalance:balance, paperTrading, riskPerTrade });
  const apisResult = autopilotV2.activateAllAPIs({ momoCollectionKey:MOMO_COLLECTION_KEY, momoDisbursementKey:MOMO_DISBURSEMENT_KEY, binanceKey:process.env.BINANCE_API_KEY });
  if(loadTanakhText) autopilotV2.loadTanakhDB(loadTanakhText); else autopilotV2.loadTanakhDB("בראשיתבראאלהיםאתהשמיםואתהארץ".repeat(500));
  const startResult = autopilotV2.start();
  autopilotV2Candles = [{ close:gseCache.close, open:gseCache.open, high:gseCache.high, low:gseCache.low, volume:gseCache.vol, change:gseCache.change }];
  if(autopilotV2Interval) clearInterval(autopilotV2Interval);
  autopilotV2Interval = setInterval(async ()=>{
    try{
      let latest; if(symbol==='MTNGH'){ const g=await fetchGSE(); latest={close:g.close, open:g.open, high:g.high, low:g.low, volume:g.vol, change:g.change}; } else { const br=await fetch(`https://api.binance.com/api/v3/ticker/24hr?symbol=${symbol.toUpperCase()}`); const bd=await br.json(); latest={close:parseFloat(bd.lastPrice), open:parseFloat(bd.openPrice), high:parseFloat(bd.highPrice), low:parseFloat(bd.lowPrice), volume:parseFloat(bd.volume), change:parseFloat(bd.priceChangePercent)}; }
      autopilotV2Candles.push(latest); if(autopilotV2Candles.length>20) autopilotV2Candles.shift();
      const result = await autopilotV2.autopilotTickV2(autopilotV2Candles);
      console.log(`[V2] ${result.decision.word}=${result.decision.totalWeight} Dom=${result.decision.dominantLetter} TP=${result.decision.tpsl.tp.toFixed(2)} SL=${result.decision.tpsl.sl.toFixed(2)} ${result.decision.action} Bal=${result.balance.toFixed(2)} Profit=${result.stats.profit.toFixed(2)}`);
    }catch(e){ console.error('V2 tick',e.message); }
  }, intervalSec*1000);
  res.json({ ...startResult, intervalSec, apis:apisResult, message:`V2 STARTED B,G,D,H,V TP/SL + Tanakh 1.2M + ALL APIs`, tanakh:autopilotV2.tanakhDB.size });
});
app.post('/api/autopilot/v2/stop', (req,res)=>{ if(!autopilotV2) return res.json({error:'V2 not running'}); if(autopilotV2Interval) clearInterval(autopilotV2Interval); res.json(autopilotV2.stop()); });
app.get('/api/autopilot/v2/status', (req,res)=>{ if(!autopilotV2) return res.json({running:false,message:'V2 not started'}); res.json(autopilotV2.getStatus()); });
app.post('/api/autopilot/v2/tick', async (req,res)=>{ if(!autopilotV2) return res.status(400).json({error:'Start V2 first'}); const result=await autopilotV2.autopilotTickV2(req.body.candles||autopilotV2Candles); res.json(result); });
app.post('/api/tanakh/load', (req,res)=>{ if(!autopilotV2) autopilotV2 = new MuluiAutopilotV2({ paperTrading:true }); const source = req.body.text || req.body.filePath || ''; if(!source) return res.status(400).json({error:'Provide text'}); res.json(autopilotV2.loadTanakhDB(source)); });
app.get('/api/tanakh/search', (req,res)=>{ if(!autopilotV2 || !autopilotV2.tanakhDB.loaded) return res.status(400).json({error:'Load Tanakh first'}); res.json(autopilotV2.tanakhDB.searchHolyWord(req.query.word||'טוב')); });
app.get('/api/tanakh/tpsl/:letter/:price', (req,res)=>{ if(!autopilotV2) return res.status(400).json({error:'Load Tanakh first'}); res.json(autopilotV2.tanakhDB.getTPSLFromTanakh(req.params.letter, parseFloat(req.params.price))); });
app.get('/api/health', (req,res)=>{ res.json({ status:'MULUI V2 TP/SL B,G,D,H,V + TANAKH 1.2M + ALL APIs LIVE', timestamp:new Date().toISOString(), gse:gseCache, momo:{ configured:!!MOMO_COLLECTION_KEY }, patterns:'א=1-30-80 CORRECTED | B,G,D,H,V TP/SL', proven: PROVEN_PATTERNS || {}, v1:{ running: autopilotBot ? autopilotBot.isRunning : false }, v2:{ running: autopilotV2 ? autopilotV2.isRunning : false, tanakh: autopilotV2 ? { loaded:autopilotV2.tanakhDB.loaded, size:autopilotV2.tanakhDB.size } : null } }); });
app.get('*', (req,res)=>{ const p = path.join(__dirname,'public','MULUI_AI_AUTOPILOT.html'); if(fs.existsSync(p)) res.sendFile(p); else res.sendFile(path.join(__dirname,'public','index.html')); });
app.listen(PORT, ()=>{ console.log(`\n🌍 MULUI V2 TP/SL B,G,D,H,V + Tanakh 1.2M + ALL APIs LIVE on ${PORT}\n`); });
