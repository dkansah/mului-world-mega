// MULUI AI AUTOPILOT TRADING BOT - Follows 22 Hebrew Patterns to Make Gains
// DKA Innovation 2026 - א=1-30-80 CORRECTED
// Pattern: Every letter = market signal, Every word = trade decision
// טוב=17 = BUY, יהוה=26 = HOLD, אלהים=86 = STRONG BUY, אמת=441 = TAKE PROFIT

const PATTERNS = {
  'א': { w:1, pat:[1,30,80], name:'אלף', signal:'BEGIN - New Trend Start', action:'BUY', strength:0.3 },
  'ב': { w:2, pat:[2,10,400], name:'בית', signal:'HOUSE - Consolidation', action:'HOLD', strength:0.1 },
  'ג': { w:3, pat:[3,10,40,30], name:'גימל', signal:'CAMEL - Carry Momentum', action:'BUY', strength:0.4 },
  'ד': { w:4, pat:[4,30,400], name:'דלת', signal:'DOOR - Breakout', action:'BUY', strength:0.6 },
  'ה': { w:5, pat:[5,1], name:'הא', signal:'WINDOW - Reveal', action:'HOLD', strength:0.2 },
  'ו': { w:6, pat:[6,6], name:'וו', signal:'HOOK - Connect Trend', action:'BUY', strength:0.5 },
  'ז': { w:7, pat:[7,10,50], name:'זין', signal:'WEAPON - Sharp Move', action:'BUY', strength:0.7 },
  'ח': { w:8, pat:[8,10,400], name:'חית', signal:'FENCE - Support', action:'HOLD', strength:0.3 },
  'ט': { w:9, pat:[9,10,400], name:'טית', signal:'SERPENT - Reversal', action:'SELL', strength:0.6 },
  'י': { w:10, pat:[10,6,4], name:'יוד', signal:'HAND - Small Move', action:'HOLD', strength:0.2 },
  'כ': { w:20, pat:[20,80], name:'כף', signal:'PALM - Open', action:'BUY', strength:0.5 },
  'ל': { w:30, pat:[30,40,4], name:'למד', signal:'LIBRA - BALANCE - מאזניים', action:'BALANCE', strength:1.0 }, // Most important
  'מ': { w:40, pat:[40,40], name:'מם', signal:'WATER - Flow', action:'HOLD', strength:0.4 },
  'נ': { w:50, pat:[50,6,50], name:'נון', signal:'FISH - Fast Move', action:'BUY', strength:0.6 },
  'ס': { w:60, pat:[60,40,20], name:'סמך', signal:'SUPPORT - Hold', action:'HOLD', strength:0.3 },
  'ע': { w:70, pat:[70,10,50], name:'עין', signal:'EYE - See Opportunity', action:'BUY', strength:0.7 },
  'פ': { w:80, pat:[80,1], name:'פא', signal:'MOUTH - Speak/Sell Signal', action:'SELL', strength:0.5 },
  'צ': { w:90, pat:[90,4,10], name:'צדי', signal:'FISHHOOK - Catch Profit', action:'TAKE_PROFIT', strength:0.8 },
  'ק': { w:100, pat:[100,6,80], name:'קוף', signal:'HOLY - 100 Qoph', action:'STRONG_BUY', strength:0.9 },
  'ר': { w:200, pat:[200,10,300], name:'ריש', signal:'HEAD - Top', action:'SELL', strength:0.7 },
  'ש': { w:300, pat:[300,10,50], name:'שין', signal:'TEETH - Volatile', action:'HOLD', strength:0.4 },
  'ת': { w:400, pat:[400,6], name:'תו', signal:'MARK - End Cycle', action:'TAKE_PROFIT', strength:0.8 },
};

const LETTERS = Object.keys(PATTERNS);

// Holy words that trigger trades - gematria
const HOLY_TRADES = {
  17: { word:'טוב', meaning:'GOOD', action:'BUY', points:1000, reason:'טוב=17 = Good trade' },
  26: { word:'יהוה', meaning:'YHVH', action:'STRONG_BUY', points:2000, reason:'Divine hold' },
  86: { word:'אלהים', meaning:'Elohim', action:'STRONG_BUY', points:3000, reason:'God power - strong buy' },
  100: { word:'ק', meaning:'Holy Qoph', action:'BUY', points:5000, reason:'Holy 100' },
  441: { word:'אמת', meaning:'Truth', action:'TAKE_PROFIT', points:500, reason:'אמת=441 = Truth - take profit' },
  100079: { word:'Genesis Total', meaning:'Genesis', action:'STRONG_BUY', points:100079, reason:'Genesis total weight' },
};

class MuluiAutopilotAI {
  constructor(config = {}) {
    this.config = {
      exchange: config.exchange || 'GSE', // GSE, BINANCE, NYSE
      symbol: config.symbol || 'MTNGH',
      initialBalance: config.initialBalance || 1000, // GHS or USD
      riskPerTrade: config.riskPerTrade || 0.02, // 2% per trade
      autopilot: config.autopilot || false,
      paperTrading: config.paperTrading !== false, // default paper
      ...config
    };
    this.balance = this.config.initialBalance;
    this.positions = [];
    this.tradeHistory = [];
    this.lettersHistory = [];
    this.isRunning = false;
    this.stats = { wins:0, losses:0, totalTrades:0, profit:0, winRate:0 };
    this.lastSignal = null;
  }

  // OTIOT Engine: Candle -> Hebrew Letter
  candleToLetter(candle) {
    // Formula: (close*100 + vol/10000 + |change|*100 + 30) %22
    // 30 = ל = Libra balance = מאזניים
    const pricePart = candle.close * 100;
    const volPart = (candle.volume || candle.vol || 0) / 10000;
    const changePart = Math.abs(candle.change || 0) * 100;
    const lamed = 30;
    const total = pricePart + volPart + changePart + lamed;
    const idx = Math.floor(total) % 22;
    const letter = LETTERS[idx];
    return {
      letter,
      weight: PATTERNS[letter].w,
      pattern: PATTERNS[letter].pat,
      signal: PATTERNS[letter].signal,
      action: PATTERNS[letter].action,
      strength: PATTERNS[letter].strength,
      rawTotal: total
    };
  }

  // Process multiple candles -> word -> trade decision
  analyzeMarket(candles) {
    // Convert each candle to letter
    const lettersData = candles.map(c => this.candleToLetter(c));
    const letters = lettersData.map(l => l.letter);
    const word = letters.join('');
    const totalWeight = lettersData.reduce((s,l) => s + l.weight, 0);
    
    // Reduced weight (gematria reduction)
    let reduced = totalWeight;
    while (reduced > 9 && ![17,26,86].includes(reduced)) {
      reduced = reduced.toString().split('').reduce((a,b) => a + parseInt(b),0);
    }

    // Check for holy words
    let holyTrade = null;
    if (HOLY_TRADES[totalWeight]) holyTrade = HOLY_TRADES[totalWeight];
    else if (HOLY_TRADES[reduced]) holyTrade = HOLY_TRADES[reduced];
    else if (word === 'טוב' || word.includes('טוב')) holyTrade = HOLY_TRADES[17];
    else if (word === 'אמת') holyTrade = HOLY_TRADES[441];

    // AI Decision: Combine letter signals + holy word + strength
    let decision = {
      timestamp: new Date().toISOString(),
      word,
      letters: lettersData,
      totalWeight,
      reduced,
      holyTrade,
      signals: lettersData.map(l => `${l.letter}(${l.action})`).join(' + '),
      confidence: 0,
      action: 'HOLD',
      reason: ''
    };

    // Calculate confidence from strengths
    const avgStrength = lettersData.reduce((s,l) => s + l.strength, 0) / lettersData.length;
    
    // 22 Patterns Logic:
    // If ל appears (balance) -> high confidence
    // If טוב appears -> BUY
    // If multiple BUY signals -> STRONG_BUY
    // If אמת appears -> TAKE_PROFIT
    
    const buyCount = lettersData.filter(l => l.action === 'BUY' || l.action === 'STRONG_BUY').length;
    const sellCount = lettersData.filter(l => l.action === 'SELL').length;
    const hasLamed = letters.includes('ל'); // Balance - most important
    const hasQoph = letters.includes('ק'); // Holy 100

    if (holyTrade) {
      decision.action = holyTrade.action;
      decision.confidence = 0.9;
      decision.reason = `Holy word ${holyTrade.word}=${holyTrade.meaning} detected! ${holyTrade.reason}`;
    } else if (hasLamed && buyCount >=2) {
      decision.action = 'STRONG_BUY';
      decision.confidence = 0.85;
      decision.reason = `ל (Libra Balance) + ${buyCount} BUY signals = Strong Buy - מאזניים balanced`;
    } else if (buyCount >=2) {
      decision.action = 'BUY';
      decision.confidence = 0.6 + avgStrength*0.3;
      decision.reason = `${buyCount} BUY signals from 22 patterns: ${decision.signals}`;
    } else if (sellCount >=2) {
      decision.action = 'SELL';
      decision.confidence = 0.6 + avgStrength*0.3;
      decision.reason = `${sellCount} SELL signals: ${decision.signals}`;
    } else if (hasQoph) {
      decision.action = 'STRONG_BUY';
      decision.confidence = 0.8;
      decision.reason = 'ק (Qoph 100) Holy signal';
    } else {
      decision.action = 'HOLD';
      decision.confidence = 0.3;
      decision.reason = `Mixed signals, waiting for טוב=17. Word ${word}=${totalWeight}`;
    }

    this.lastSignal = decision;
    this.lettersHistory.push(decision);
    if (this.lettersHistory.length > 100) this.lettersHistory.shift();

    return decision;
  }

  // Execute trade (paper or real)
  executeTrade(decision, currentPrice) {
    if (decision.confidence < 0.5) {
      return { executed:false, reason:'Low confidence <0.5, HOLD' };
    }

    const riskAmount = this.balance * this.config.riskPerTrade;
    let trade = null;

    if (decision.action === 'BUY' || decision.action === 'STRONG_BUY') {
      const qty = riskAmount / currentPrice;
      const multiplier = decision.action === 'STRONG_BUY' ? 1.5 : 1;
      const finalQty = qty * multiplier;
      
      trade = {
        id: Date.now(),
        type: 'BUY',
        symbol: this.config.symbol,
        price: currentPrice,
        quantity: finalQty,
        amount: finalQty * currentPrice,
        timestamp: new Date().toISOString(),
        decision,
        paper: this.config.paperTrading
      };
      
      if (this.balance >= trade.amount) {
        this.balance -= trade.amount;
        this.positions.push(trade);
        this.tradeHistory.push(trade);
        this.stats.totalTrades++;
      }

    } else if (decision.action === 'SELL' || decision.action === 'TAKE_PROFIT') {
      if (this.positions.length >0) {
        // Close last position
        const lastPos = this.positions.pop();
        const profit = (currentPrice - lastPos.price) * lastPos.quantity;
        this.balance += lastPos.quantity * currentPrice;
        
        trade = {
          id: Date.now(),
          type: 'SELL',
          symbol: this.config.symbol,
          price: currentPrice,
          quantity: lastPos.quantity,
          amount: lastPos.quantity * currentPrice,
          profit,
          timestamp: new Date().toISOString(),
          decision,
          closedTrade: lastPos,
          paper: this.config.paperTrading
        };
        
        this.tradeHistory.push(trade);
        this.stats.totalTrades++;
        this.stats.profit += profit;
        if (profit >0) this.stats.wins++; else this.stats.losses++;
        this.stats.winRate = this.stats.totalTrades ? (this.stats.wins / this.stats.totalTrades *100).toFixed(1) : 0;
      }
    }

    return { executed: !!trade, trade, balance:this.balance, stats:this.stats };
  }

  // Autopilot loop - called every N seconds with new candles
  async autopilotTick(candles) {
    if (!this.isRunning) return { running:false };
    
    const currentPrice = candles[candles.length-1].close;
    const decision = this.analyzeMarket(candles.slice(-3)); // last 3 candles = 3 letters
    
    let execution = { executed:false };
    if (decision.action !== 'HOLD') {
      execution = this.executeTrade(decision, currentPrice);
    }

    return {
      running: true,
      timestamp: new Date().toISOString(),
      currentPrice,
      decision,
      execution,
      balance: this.balance,
      positions: this.positions.length,
      stats: this.stats,
      paperTrading: this.config.paperTrading
    };
  }

  start() {
    this.isRunning = true;
    console.log(`🤖 MULUI AI Autopilot STARTED - ${this.config.symbol} - Balance ${this.balance} - Paper: ${this.config.paperTrading}`);
    return { started:true, config:this.config, balance:this.balance };
  }

  stop() {
    this.isRunning = false;
    console.log(`🛑 Autopilot STOPPED - Final balance ${this.balance} Profit ${this.stats.profit}`);
    return { stopped:true, finalBalance:this.balance, stats:this.stats, tradeHistory:this.tradeHistory.slice(-10) };
  }

  getStatus() {
    return {
      isRunning: this.isRunning,
      config: this.config,
      balance: this.balance,
      positions: this.positions,
      lastSignal: this.lastSignal,
      stats: this.stats,
      lettersHistory: this.lettersHistory.slice(-5),
      paperTrading: this.config.paperTrading
    };
  }
}

module.exports = { MuluiAutopilotAI, PATTERNS, HOLY_TRADES };
