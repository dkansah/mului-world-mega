# Deploy Guide - dkansah

## GitHub Repo: https://github.com/dkansah/mului-world-mega

### Steps:
1. Create repo on GitHub named `mului-world-mega` (public)
2. Run in backend folder:
```bash
git init
git add .
git commit -m "MULUI WORLD MEGA - initial - א=1-30-80"
git branch -M main
git remote add origin https://github.com/dkansah/mului-world-mega.git
git push -u origin main
```
3. Go to https://render.com/deploy?repo=https://github.com/dkansah/mului-world-mega
4. Set env vars and deploy.

Live: https://mului-world-mega.onrender.com
