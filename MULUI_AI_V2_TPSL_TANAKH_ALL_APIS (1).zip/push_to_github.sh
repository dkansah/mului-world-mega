#!/bin/bash
# Push to dkansah/mului-world-mega - One click
echo "🌍 MULUI WORLD MEGA - Pushing to github.com/dkansah/mului-world-mega"
echo "Pattern א=1-30-80 CORRECTED"

# init if needed
if [ ! -d .git ]; then
  git init
  echo "Git init done"
fi

git add .
git commit -m "MULUI WORLD MEGA - All exchanges + banks + MoMo + 1.2M - א=1-30-80 CORRECTED - DKA $(date)"

git branch -M main

# remove old origin if exists
git remote remove origin 2>/dev/null

git remote add origin https://github.com/dkansah/mului-world-mega.git

echo "Pushing to https://github.com/dkansah/mului-world-mega.git ..."
git push -u origin main

echo "✅ Done! Now deploy:"
echo "https://render.com/deploy?repo=https://github.com/dkansah/mului-world-mega"
echo "Live will be: https://mului-world-mega.onrender.com"
